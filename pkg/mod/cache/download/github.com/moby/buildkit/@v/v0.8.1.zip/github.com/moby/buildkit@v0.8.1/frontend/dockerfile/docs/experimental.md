# Dockerfile frontend syntaxes

This page has moved to
[Dockerfile frontend documentation](/frontend/dockerfile/docs/syntax.md)
