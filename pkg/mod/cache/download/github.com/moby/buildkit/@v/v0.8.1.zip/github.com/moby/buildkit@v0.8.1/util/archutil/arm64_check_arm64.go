// +build arm64

package archutil

func arm64Supported() error {
	return nil
}
