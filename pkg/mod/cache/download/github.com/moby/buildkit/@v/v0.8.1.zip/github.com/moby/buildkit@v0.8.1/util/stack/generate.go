package stack

//go:generate protoc -I=. -I=../../vendor/ --go_out=. stack.proto
