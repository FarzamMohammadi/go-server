// +build ppc64le

package archutil

func ppc64leSupported() error {
	return nil
}
