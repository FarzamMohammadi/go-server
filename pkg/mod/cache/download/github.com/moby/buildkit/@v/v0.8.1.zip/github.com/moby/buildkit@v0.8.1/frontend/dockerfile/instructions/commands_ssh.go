package instructions

func isSSHMountsSupported() bool {
	return true
}
