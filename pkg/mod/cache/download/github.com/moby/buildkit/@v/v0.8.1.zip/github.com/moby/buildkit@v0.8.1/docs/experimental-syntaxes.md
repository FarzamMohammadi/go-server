# Dockerfile frontend syntaxes

Documentation for Dockerfile syntaxes can be found in the
[Dockerfile frontend documentation](/frontend/dockerfile/docs/syntax.md)
