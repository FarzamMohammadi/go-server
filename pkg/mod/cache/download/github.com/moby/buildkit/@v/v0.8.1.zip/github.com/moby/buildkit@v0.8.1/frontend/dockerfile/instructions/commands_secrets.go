package instructions

func isSecretMountsSupported() bool {
	return true
}
