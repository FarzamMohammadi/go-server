package winapi

const PROCESS_ALL_ACCESS uint32 = 2097151
