### Updating

If an update to this app is required, it must be done manually via `npm run-script build` since the `node_modules` are not shared.
