package terminal

import (
	"errors"
)

var (
	InterruptErr = errors.New("interrupt")
)
